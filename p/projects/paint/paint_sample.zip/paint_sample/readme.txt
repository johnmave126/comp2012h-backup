After unzipping, FTP the whole directory to your linux account.
To run the sample program, you should "chmod" the executable:

% chmod 750 paint.linux

After that, type "paint.linux" on the command prompt.