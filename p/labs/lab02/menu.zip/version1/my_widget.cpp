#include <iostream>
using namespace std;

#include "my_widget.h"

MyMainWindow::MyMainWindow(QWidget* parent, const char* name)
:QMainWindow(parent, name)
{
	CreateMenu();

	// create a button
	buttonExit = new QPushButton("Exit", this, 0);
	buttonExit->setGeometry(60, 60, 100, 40);
}

void MyMainWindow::CreateMenu()
{
	QPopupMenu* file = new QPopupMenu(this);

	file->insertItem("Testing");
	file->insertItem("Exit");
	menuBar()->insertItem("File", file);

	QPopupMenu* help = new QPopupMenu(this);
	help->insertItem("About");
	menuBar()->insertItem("Help", help);
}
