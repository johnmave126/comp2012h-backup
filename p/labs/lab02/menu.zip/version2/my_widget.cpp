#include <iostream>
using namespace std;

#include "my_widget.h"

MyMainWindow::MyMainWindow(QWidget* parent, const char* name)
:QMainWindow(parent, name)
{
	CreateMenu();

	// create a button
	buttonExit = new QPushButton("Exit", this, 0);
	buttonExit->setGeometry(60, 60, 100, 40);

	// connect the "clicked" signal of the QPushButton buttonExit
	// to the "OnExit()" slot of this MyMainWindow object.
	// So, if buttonExit is clicked, this->OnExit() will be called.
	QObject::connect(buttonExit, SIGNAL(clicked()), this, SLOT(OnExit()));

	// PS: connect() is a static member function of QObject.
}

void MyMainWindow::CreateMenu()
{
	QPopupMenu* file = new QPopupMenu(this);

	// this MyMainWindow object's OnTesting slot/function
	// will be called if "Testing" menu item is clicked.
	file->insertItem("Testing", this, SLOT(OnTesting()));

	file->insertItem("Exit", this, SLOT(OnExit()));
	menuBar()->insertItem("File", file);

	QPopupMenu* help = new QPopupMenu(this);
	help->insertItem("About", this, SLOT(OnAbout()));
	menuBar()->insertItem("Help", help);
}

void MyMainWindow::OnTesting()
{
	QString caption("Testing");
	QString text("Testing is clicked.");

	// prompt a modal dialog
	QMessageBox::information(this, caption, text, QMessageBox::Ok);

	cout << "You could also use cout here! " << endl;
}

void MyMainWindow::OnExit()
{
	// qApp is a global pointer points to
	// our application object (QApplication)
	qApp->quit(); // quit this application program
}

void MyMainWindow::OnAbout()
{
	QMessageBox::about(this, "About", "Type something here...");
}
